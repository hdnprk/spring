package com.javaEdu.myapp.hr.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.javaEdu.myapp.hr.model.EmpVO;
import com.javaEdu.myapp.hr.service.IEmpService;

@Controller
public class EmpController {
	
	@Autowired
	IEmpService empService;
	
	@RequestMapping(value="/hr/count")
	// 메소드가 '/hr/count' 라는 경로로 들어오는 http 요청을 처리 하도록 지정함.
	// 사용자가 브라우저에서 'http://domain.com/hr/count' 같은 url로 요청을 모내면, 이 메소드가 그 요청을 처리한다.
	public String empCount(
		@RequestParam(value="deptid", required=false, defaultValue="0") int deptid, Model model) {
		// http 요청의 파라미터 중 'deptid'라는 이름의 파라미터 값을 이 메소드의 'deptid' 매개변수로 전달 하도록 함.
		// required : 파라미터가 필수인가 아닌가 (false 필수가 아님) (파라미터 없이 요청을 보내도 에러 x)
		// defaultValue=0 : deptid 파라미터가 제공되지 않았을 경우 기본값으로 0을 사용할 것
		if(deptid==0) {
			model.addAttribute("count", empService.getEmpCount());
		}else {
			model.addAttribute("count", empService.getEmpCount(deptid));
		}
		return "hr/count";
		// 문자열 반환 : 뷰의 이름을 나타내며, 이 이름을 사용하여 클라이언트에게 응답할 뷰를 결정함. 'hr/count'라는 이름의 뷰를 찾아 요청에 대한 응답으로 사용하게 됨.
	}
	
	@RequestMapping(value= {"/hr", "hr/list"})
	public String getAllEmps(Model model) {
		List<EmpVO>empList = empService.getEmpList();
		model.addAttribute("empList", empList);
		return "hr/list";
	}
	
	@RequestMapping(value="/hr/{employeeId}")
	public String getEmpInfo(@PathVariable int employeeId, Model model) {
		// @PathVariable URI 경로에서 변수를 추출하여 메소드 매개변수에 바인딩 하는데 사용됨
		EmpVO emp = empService.getEmpInfo(employeeId);
		model.addAttribute("emp", emp);
		return "hr/view";
	}
	
	@RequestMapping(value="/hr/insert", method=RequestMethod.GET)
	// insert form을 사용자에게 보여주는 방식이 get
	public String insertEmp(Model model) {
		model.addAttribute("deptList", empService.getAllDeptId());
		model.addAttribute("jobList", empService.getAllJobId()); 
		model.addAttribute("managerList", empService.getAllManagerId());
		return "/hr/insertform";
	}
	
	@RequestMapping(value="/hr/insert", method=RequestMethod.POST)
	// 데이터를 post 방식으로 추가 한다.
	public String insertEmp(EmpVO emp, Model model) {
		empService.insertEmp(emp);
		return "redirect:/hr";
		// /hr 경로로 리디렉션 됨
	}
	
	@RequestMapping(value="/hr/update", method=RequestMethod.GET)
	// get으로 요청이 들어올 때 직원 정보를 업데이트 하기 위한 폼을 제공 한다.
	public String updateEmp(int empid, Model model) {
		model.addAttribute("emp", empService.getEmpInfo(empid));
		model.addAttribute("deptList", empService.getAllDeptId());
		model.addAttribute("jobList", empService.getAllJobId());
		model.addAttribute("managerList", empService.getAllManagerId());
		return "hr/updateform";
	}
	
	@RequestMapping(value="/hr/update", method=RequestMethod.POST)
	public String updateEmp(EmpVO emp, Model model) {
		empService.updateEmp(emp);
		return "redirect:/hr/"+emp.getEmployeeId();
		// 처리가 완료된 후에 "/hr/{empId}" 경로로 리디렉션 됨 리디렉션할 url이 생성 된다
		// ex) /hr/1234(employeeId)
	}
	
	@RequestMapping(value="/hr/delete", method=RequestMethod.GET)
	public String deleteEmp(int empid, Model model) {
		model.addAttribute("emp", empService.getEmpInfo(empid));
		return "hr/deleteform";
	}
	
	@RequestMapping(value="/hr/delete", method=RequestMethod.POST)
	public String deleteEmp(int empid, String email, Model model) {
		empService.deleteEmp(empid, email);
		return "redirect:/hr";
	}
	
	@ExceptionHandler({RuntimeException.class})
	//특정 예외를 처리하는 메소드
	public ModelAndView rutimeException(HttpServletRequest request, Exception ex) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("url", request.getRequestURI());
		// 예외가 발생한 요청의 URI를 모델에 추가
		mav.addObject("exception", ex);
		// 발생한 예외 객체를 모델에 추가
		mav.setViewName("error/runtime");
		// 예외 처리를 위해 사용한 뷰의 이름을 지정함, error/runtime이라는 뷰파일을 사용하여 사용자에게 예외 정보를 보여줌
		return mav;
	}
	
	@RequestMapping(value="/hr/json")
	public @ResponseBody List<EmpVO>getEmpJSONList() {
		// 컨트롤러 메소드에서 반환하는 값을 HTTP 응답 본문(Body)에 직접 쓰도록 지시
		// 메소드에 적용시, Spring은 해당 메소드가 반환하는 데이터를 http 응답의 본문으로 전송
		// 자동으로 적절한 형식 (JSON, XML) 등으로 변환 과정을 Spring의 메시지 컨버터에 의해 처리 됨
		List<EmpVO> empList = empService.getEmpList();
		return empList;
	}
	
	@RequestMapping(value="/hr/json/{employeeId}")
	public @ResponseBody EmpVO getEmpJsonInfo (@PathVariable int employeeId) {
		EmpVO emp = empService.getEmpInfo(employeeId);
		return emp;
	}
	
	@RequestMapping(value="/hr/ajax")
	public @ResponseBody EmpVO getEmpByJSON(@RequestBody List<Map<String, Object>> datas) {
		// 클라이언트로 부터 받은 http 요청을 java 객체로 변환하여 메소드로 전달, 요청 본문은 json 배열
		// 배열의 요소는 Map 형식으로 변환됨
		// @RequestBody 이 json 데이터를 자바의 List<Map<String,Object>> 타입으로 자동 변환 하는데 사용됨
		Map<String, Object> data = datas.get(0);
		int employeeId = Integer.parseInt((String)data.get("value"));
		EmpVO emp = empService.getEmpInfo(employeeId);
		return emp;
	}
	
	
	
}
