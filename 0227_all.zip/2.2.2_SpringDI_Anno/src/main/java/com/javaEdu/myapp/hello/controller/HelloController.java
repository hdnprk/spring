package com.javaEdu.myapp.hello.controller;

import org.springframework.stereotype.Controller;

import com.javaEdu.myapp.hello.service.IHelloService;

@Controller
public class HelloController {
	

	IHelloService helloService;
	
}
