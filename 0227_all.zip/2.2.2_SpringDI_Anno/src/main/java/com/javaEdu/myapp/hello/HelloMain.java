package com.javaEdu.myapp.hello;

public class HelloMain {

}
