package com.javaEdu.myapp.hello.service;

public interface IHelloService {
	String sayHello(String name);
	String sayGoodbye(String name);
}
