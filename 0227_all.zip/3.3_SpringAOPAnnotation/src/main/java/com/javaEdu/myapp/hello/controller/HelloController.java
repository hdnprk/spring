package com.javaEdu.myapp.hello.controller;

import org.springframework.stereotype.Controller;
import com.javaEdu.myapp.hello.service.IHelloService;

@Controller
public class HelloController {

	IHelloService helloService;
	

	public void hello(String name) {
		System.out.println("실행 결과 : " + helloService.sayHello(name));
	}


	public void goodbye(String name) {
		System.out.println("HelloController : " + helloService.sayGoodbye(name));
		
	}

}
