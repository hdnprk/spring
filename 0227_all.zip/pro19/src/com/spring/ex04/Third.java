package com.spring.ex04;

public class Third {

}
