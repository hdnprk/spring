package com.spring.ex04;

public class First {
	public First() {
		System.out.println("First 생성자 호출");
	}
}
