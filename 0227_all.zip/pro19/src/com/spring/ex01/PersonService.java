package com.spring.ex01;

public interface PersonService {
	public void sayHello();
}
