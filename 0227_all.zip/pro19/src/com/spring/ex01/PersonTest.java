package com.spring.ex01;

public class PersonTest {
	public static void main(String[] args) {
		
	}
}
