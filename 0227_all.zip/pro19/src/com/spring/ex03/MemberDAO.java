package com.spring.ex03;

public interface MemberDAO {
	public void listMembers();
}
