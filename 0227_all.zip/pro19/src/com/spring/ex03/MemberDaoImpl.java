package com.spring.ex03;

public class MemberDaoImpl implements MemberDAO {

	@Override
	public void listMembers() {
		System.out.println("listMembers 메소드 호출");
		System.out.println("회원정보를 조회합니다.");
		
	}
	
}
